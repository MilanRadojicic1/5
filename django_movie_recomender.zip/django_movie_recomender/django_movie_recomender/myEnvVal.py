import os
# Set environment variables
def setVar():
    os.environ['EMAIL_USER'] = 'mika60773@gmail.com'
    os.environ['EMAIL_PASSWORD'] = 'Milance1008'